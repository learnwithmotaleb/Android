package com.motaleb.countryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button1,button2,button3,
            button4,button5,
            button6,button7,button8,
            button9,button10,
            button11,button12,button13,button14,button15,button16,
            button17,button18,button19,button20,button21,button22,button23,
            button24,button25,button26,button27,
            button28,button29,button30,button31,button32,
            button33,button34,button35,button36,
            button37,button38,button39,button40,
            button41,button42,button43,
            button45,button46,button47,button48,button49,button50,
            button51,button52,button53,button54,button55,button56,button57,button58,
            button59,button60,button61,button62,button63,button64;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //=======button find=============start===

        button1 = findViewById(R.id.btn1id);
        button2 = findViewById(R.id.btn2id);
        button3 = findViewById(R.id.btn3id);
        button4 = findViewById(R.id.btn4id);
        button5 = findViewById(R.id.btn5id);
        button6 = findViewById(R.id.btn6id);
        button7 = findViewById(R.id.btn7id);
        button8 = findViewById(R.id.btn8id);
        button9 = findViewById(R.id.btn9id);
        button10 = findViewById(R.id.btn10id);
        button11 = findViewById(R.id.btn11id);
        button12 = findViewById(R.id.btn12id);
        button13 = findViewById(R.id.btn13id);
        button14 = findViewById(R.id.btn14id);
        button15 = findViewById(R.id.btn15id);
        button16 = findViewById(R.id.btn16id);
        button17 = findViewById(R.id.btn17id);
        button18 = findViewById(R.id.btn18id);
        button19 = findViewById(R.id.btn19id);
        button20 = findViewById(R.id.btn20id);
        button21 = findViewById(R.id.btn21id);
        button22 = findViewById(R.id.btn22id);
        button23 = findViewById(R.id.btn23id);
        button24 = findViewById(R.id.btn24id);
        button25 = findViewById(R.id.btn25id);
        button26 = findViewById(R.id.btn26id);
        button27 = findViewById(R.id.btn27id);
        button28 = findViewById(R.id.btn28id);
        button29 = findViewById(R.id.btn29id);
        button30 = findViewById(R.id.btn30id);
        button31 = findViewById(R.id.btn31id);
        button32 = findViewById(R.id.btn32id);
        button33 = findViewById(R.id.btn33id);
        button34 = findViewById(R.id.btn34id);
        button35 = findViewById(R.id.btn35id);
        button36 = findViewById(R.id.btn36id);
        button37 = findViewById(R.id.btn37id);
        button38 = findViewById(R.id.btn38id);
        button39 = findViewById(R.id.btn39id);
        button40 = findViewById(R.id.btn40id);
        button41 = findViewById(R.id.btn41id);
        button42 = findViewById(R.id.btn42id);
        button43 = findViewById(R.id.btn43id);
        button45 = findViewById(R.id.btn45id);
        button46 = findViewById(R.id.btn46id);
        button47 = findViewById(R.id.btn47id);
        button48 = findViewById(R.id.btn48id);
        button49 = findViewById(R.id.btn49id);
        button50 = findViewById(R.id.btn50id);
        button51 = findViewById(R.id.btn51id);
        button52 = findViewById(R.id.btn52id);
        button53 = findViewById(R.id.btn53id);
        button54 = findViewById(R.id.btn54id);
        button55 = findViewById(R.id.btn55id);
        button56 = findViewById(R.id.btn56id);
        button57 = findViewById(R.id.btn57id);
        button58 = findViewById(R.id.btn58id);
        button59 = findViewById(R.id.btn59id);
        button60 = findViewById(R.id.btn60id);
        button61 = findViewById(R.id.btn61id);
        button62 = findViewById(R.id.btn62id);
        button63 = findViewById(R.id.btn63id);
        button64 = findViewById(R.id.btn64id);

        //button find ===============end==========
        //=======set onclickListener start =======

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        button10.setOnClickListener(this);
        button11.setOnClickListener(this);
        button12.setOnClickListener(this);
        button13.setOnClickListener(this);
        button14.setOnClickListener(this);
        button15.setOnClickListener(this);
        button16.setOnClickListener(this);
        button17.setOnClickListener(this);
        button18.setOnClickListener(this);
        button19.setOnClickListener(this);
        button20.setOnClickListener(this);
        button21.setOnClickListener(this);
        button22.setOnClickListener(this);
        button23.setOnClickListener(this);
        button24.setOnClickListener(this);
        button25.setOnClickListener(this);
        button26.setOnClickListener(this);
        button27.setOnClickListener(this);
        button28.setOnClickListener(this);
        button29.setOnClickListener(this);
        button30.setOnClickListener(this);
        button31.setOnClickListener(this);
        button32.setOnClickListener(this);
        button33.setOnClickListener(this);
        button34.setOnClickListener(this);
        button35.setOnClickListener(this);
        button36.setOnClickListener(this);
        button37.setOnClickListener(this);
        button38.setOnClickListener(this);
        button39.setOnClickListener(this);
        button40.setOnClickListener(this);
        button41.setOnClickListener(this);
        button42.setOnClickListener(this);
        button43.setOnClickListener(this);
        button45.setOnClickListener(this);
        button46.setOnClickListener(this);
        button47.setOnClickListener(this);
        button48.setOnClickListener(this);
        button49.setOnClickListener(this);
        button50.setOnClickListener(this);
        button51.setOnClickListener(this);
        button52.setOnClickListener(this);
        button53.setOnClickListener(this);
        button54.setOnClickListener(this);
        button55.setOnClickListener(this);
        button56.setOnClickListener(this);
        button57.setOnClickListener(this);
        button58.setOnClickListener(this);
        button59.setOnClickListener(this);
        button60.setOnClickListener(this);
        button61.setOnClickListener(this);
        button62.setOnClickListener(this);
        button63.setOnClickListener(this);
        button64.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        Intent intent;
        if(v.getId() == R.id.btn1id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);

            intent.putExtra("keyWord","bt1");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn2id){



            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt2");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn3id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt3");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn4id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt4");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn5id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt5");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn6id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt6");
            startActivity(intent);


        }
        if(v.getId() == R.id.btn7id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt7");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn8id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt8");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn9id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt9");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn10id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt10");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn11id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt11");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn12id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt12");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn13id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt13");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn14id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt14");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn15id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt15");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn16id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt16");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn17id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt17");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn18id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt18");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn19id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt19");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn20id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt20");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn21id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt21");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn22id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt22");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn23id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt23");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn24id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt24");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn25id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt25");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn26id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt26");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn27id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt27");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn28id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt28");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn29id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt29");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn30id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt30");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn31id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt31");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn32id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt32");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn33id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt33");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn34id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt34");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn35id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt35");
            startActivity(intent);

        }

        if(v.getId() == R.id.btn36id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt36");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn37id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt37");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn38id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt38");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn39id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt39");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn40id){


            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt40");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn41id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt41");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn42id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt42");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn43id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt43");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn45id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt45");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn46id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt46");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn47id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt47");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn48id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt48");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn49id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt49");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn50id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt50");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn51id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt51");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn52id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt52");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn53id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt53");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn54id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt54");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn55id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt55");
            startActivity(intent);

        }

        if(v.getId() == R.id.btn56id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt56");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn57id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt57");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn58id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt58");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn59id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt59");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn60id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt60");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn61id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt61");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn62id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt62");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn63id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt63");
            startActivity(intent);

        }
        if(v.getId() == R.id.btn64id){

            intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("keyWord","bt64");
            startActivity(intent);

        }


    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder;
        alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);

        alertDialogBuilder.setIcon(R.drawable.bangladesh);
        alertDialogBuilder.setTitle(R.string.title);
        alertDialogBuilder.setMessage(R.string.message);
        alertDialogBuilder.setCancelable(false);

        alertDialogBuilder.setPositiveButton("yes", (dialogInterface, i) -> finish());
        alertDialogBuilder.setNegativeButton("No", (dialogInterface, i) -> dialogInterface.cancel());
        alertDialogBuilder.setNeutralButton("Cancle", (dialogInterface, i) -> dialogInterface.cancel());

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();



    }
   //============Create menu=====================================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

//        if(item.getItemId()==android.R.id.home){
//            this.finish();
//        }

        if(item.getItemId()==R.id.rateid){
            Toast.makeText(MainActivity.this, "Rate App is Click", Toast.LENGTH_SHORT).show();
            return true;
        }
        if(item.getItemId()==R.id.moreid){
            Toast.makeText(MainActivity.this, "More Apps is Click", Toast.LENGTH_SHORT).show();
            return true;
        }if(item.getItemId()==R.id.shareid){
            Toast.makeText(MainActivity.this, "Share is Click", Toast.LENGTH_SHORT).show();
            return true;
        }if(item.getItemId()==R.id.sendid){
            Toast.makeText(MainActivity.this, "Send is Click", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    //===============End menu=========================
}