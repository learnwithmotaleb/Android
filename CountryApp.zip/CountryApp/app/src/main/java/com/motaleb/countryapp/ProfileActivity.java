package com.motaleb.countryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    private TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        textView2 = findViewById(R.id.text_about);

        Bundle bundle = getIntent().getExtras();

        if(bundle != null){

            String names =bundle.getString("keyWord");
            showDetails(names);



        }

    }
    void showDetails(String names){

        if(names.equals("bt1")){
            textView2.setText(R.string.btn_text1);
        }
        if(names.equals("bt2")){
            textView2.setText(R.string.btn_text2);
        }
        if(names.equals("bt3")){
            textView2.setText(R.string.btn_text3);
        }
        if(names.equals("bt4")){
            textView2.setText(R.string.btn_text4);
        }
        if(names.equals("bt5")){
            textView2.setText(R.string.btn_text5);
        }
        if(names.equals("bt6")){

            textView2.setText(R.string.btn_text6);
        }
        if(names.equals("bt7")){

            textView2.setText(R.string.btn_text7);
        }
        if(names.equals("bt8")){

            textView2.setText(R.string.btn_text8);
        }
        if(names.equals("bt9")){

            textView2.setText(R.string.btn_text9);
        }
        if(names.equals("bt10")){

            textView2.setText(R.string.btn_text10);
        }
        if(names.equals("bt11")){

            textView2.setText(R.string.btn_text11);
        }
        if(names.equals("bt12")){

            textView2.setText(R.string.btn_text12);
        }
        if(names.equals("bt13")){

            textView2.setText(R.string.btn_text13);
        }
        if(names.equals("bt14")){

            textView2.setText(R.string.btn_text14);
        }
        if(names.equals("bt15")){

            textView2.setText(R.string.btn_text15);
        }
        if(names.equals("bt16")){

            textView2.setText(R.string.btn_text16);
        }
        if(names.equals("bt17")){

            textView2.setText(R.string.btn_text17);
        }
        if(names.equals("bt18")){

            textView2.setText(R.string.btn_text18);
        }
        if(names.equals("bt19")){

            textView2.setText(R.string.btn_text19);
        }
        if(names.equals("bt20")){

            textView2.setText(R.string.btn_text20);
        }
        if(names.equals("bt21")){

            textView2.setText(R.string.btn_text21);
        }
        if(names.equals("bt22")){

            textView2.setText(R.string.btn_text22);
        }
        if(names.equals("bt23")){

            textView2.setText(R.string.btn_text23);
        }
        if(names.equals("bt24")){

            textView2.setText(R.string.btn_text24);
        }
        if(names.equals("bt25")){

            textView2.setText(R.string.btn_text25);
        }
        if(names.equals("bt26")){

            textView2.setText(R.string.btn_text26);
        }
        if(names.equals("bt27")){

            textView2.setText(R.string.btn_text27);
        }
        if(names.equals("bt28")){

            textView2.setText(R.string.btn_text28);
        }
        if(names.equals("bt29")){

            textView2.setText(R.string.btn_text29);
        }
        if(names.equals("bt30")){

            textView2.setText(R.string.btn_text30);
        }
        if(names.equals("bt31")){

            textView2.setText(R.string.btn_text31);
        }
        if(names.equals("bt32")){

            textView2.setText(R.string.btn_text32);
        }
        if(names.equals("bt33")){

            textView2.setText(R.string.btn_text33);
        }
        if(names.equals("bt34")){

            textView2.setText(R.string.btn_text34);
        }
        if(names.equals("bt35")){

            textView2.setText(R.string.btn_text35);
        }
        if(names.equals("bt36")){

            textView2.setText(R.string.btn_text36);
        }
        if(names.equals("bt37")){

            textView2.setText(R.string.btn_text37);
        }
        if(names.equals("bt38")){

            textView2.setText(R.string.btn_text38);
        }
        if(names.equals("bt39")){

            textView2.setText(R.string.btn_text39);
        }
        if(names.equals("bt40")){

            textView2.setText(R.string.btn_text40);
        }
        if(names.equals("bt41")){

            textView2.setText(R.string.btn_text41);
        }
        if(names.equals("bt42")){

            textView2.setText(R.string.btn_text42);
        }
        if(names.equals("bt43")){

            textView2.setText(R.string.btn_text43);
        }
        if(names.equals("bt12")){

            textView2.setText(R.string.btn_text12);
        }
        if(names.equals("bt45")){

            textView2.setText(R.string.btn_text45);
        }
        if(names.equals("bt46")){

            textView2.setText(R.string.btn_text46);
        }

        if(names.equals("bt47")){

            textView2.setText(R.string.btn_text47);
        }
        if(names.equals("bt48")){

            textView2.setText(R.string.btn_text48);
        }
        if(names.equals("bt49")){

            textView2.setText(R.string.btn_text49);
        }
        if(names.equals("bt50")){

            textView2.setText(R.string.btn_text50);
        }
        if(names.equals("bt51")){

            textView2.setText(R.string.btn_text51);
        }
        if(names.equals("bt52")){

            textView2.setText(R.string.btn_text52);
        }
        if(names.equals("bt53")){

            textView2.setText(R.string.btn_text53);
        }
        if(names.equals("bt54")){

            textView2.setText(R.string.btn_text54);
        }
        if(names.equals("bt55")){

            textView2.setText(R.string.btn_text55);
        }
        if(names.equals("bt56")){

            textView2.setText(R.string.btn_text56);
        }
        if(names.equals("bt57")){

            textView2.setText(R.string.btn_text57);
        }
        if(names.equals("bt58")){

            textView2.setText(R.string.btn_text58);
        }
        if(names.equals("bt59")){

            textView2.setText(R.string.btn_text59);
        }
        if(names.equals("bt60")){

            textView2.setText(R.string.btn_text60);
        }
        if(names.equals("bt61")){

            textView2.setText(R.string.btn_text61);
        }
        if(names.equals("bt62")){

            textView2.setText(R.string.btn_text62);
        }
        if(names.equals("bt63")){

            textView2.setText(R.string.btn_text63);
        }
        if(names.equals("bt64")){

            textView2.setText(R.string.btn_text64);
        }


    }
}