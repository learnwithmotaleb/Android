package com.motaleb.navigationdrawer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle toggle;

    ///====================list view variable======
//    private ListView listView;
//    private String[] CountryName;
//    private ArrayAdapter<String> adapter;
    ///====================list view variable=====

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ///=======listview use========

//        listView = findViewById(R.id.listviewid);
//        CountryName = getResources().getStringArray(R.array.names_Country);
//        adapter = new ArrayAdapter<>(MainActivity.this,R.layout.sample_layout,R.id.textviewid,CountryName);
//        listView.setAdapter(adapter);
//
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                String value = adapter.getItem(i);
//                Toast.makeText(MainActivity.this,value,Toast.LENGTH_SHORT).show();
//
//            }
//        });

        ///=======listview use========

        drawerLayout = findViewById(R.id.drawerlayoutid);
        toggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.nav_open,R.string.nav_close);

        NavigationView navigationView = findViewById(R.id.navigationid);
        navigationView.setNavigationItemSelectedListener(this);

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(toggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent intent;

        if(item.getItemId() == R.id.homemenu){

            intent = new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);

        }
        else if(item.getItemId() == R.id.chatmenu){

            intent = new Intent(MainActivity.this,ChatActivity.class);
            startActivity(intent);

        }

        return false;
    }
}