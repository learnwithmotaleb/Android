package com.motaleb.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
    private WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webviewid);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.thedailystar.net/");
    }
    //======Backpressed
    @Override
    public void onBackPressed() {

        if(webView.canGoBack()){
            webView.goBack();
        }else{
            super.onBackPressed();
//            AlertDialog.Builder alertDialogBuilder;
//            alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
//
//            alertDialogBuilder.setIcon(R.drawable.web);
//            alertDialogBuilder.setTitle(R.string.title);
//            alertDialogBuilder.setMessage(R.string.massage);
//            alertDialogBuilder.setCancelable(false);
//
//            alertDialogBuilder.setPositiveButton("yes", (dialogInterface, i) -> finish());
//            alertDialogBuilder.setNegativeButton("No", (dialogInterface, i) -> dialogInterface.cancel());
//            alertDialogBuilder.setNeutralButton("Cancle", (dialogInterface, i) -> dialogInterface.cancel());
//
//            AlertDialog alertDialog = alertDialogBuilder.create();
//            alertDialog.show();
        }







    }
}