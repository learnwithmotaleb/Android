package com.motaleb.alertapps;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private AlertDialog.Builder alerDialogBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btnid);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alerDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alerDialogBuilder.setTitle(R.string.aler_title);
                alerDialogBuilder.setMessage(R.string.aler_massege);
                alerDialogBuilder.setIcon(R.drawable.password);
                alerDialogBuilder.setCancelable(false);

                alerDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });
                alerDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                alerDialogBuilder.setNeutralButton("Cencle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                AlertDialog alertDialog = alerDialogBuilder.create();
                alertDialog.show();



            }
        });
    }
}